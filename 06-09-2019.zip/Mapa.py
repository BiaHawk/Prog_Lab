class Graph:
	def __init__(self, number_of_vertex):
		self.number_of_vertex = number_of_vertex
		self.vertexes = []

class Vertex:
	def __init__(self, vertex_index):
		self.index = vertex_index
		self.targets = []

	def add_target(self, another_vertex_object):
		self.targets.append(another_vertex_object)

    
current_graph = Graph(int(input()))

for i in range(current_graph.number_of_vertex):
	current_vertex = Vertex(i)
	current_graph.vertexes.append(current_vertex)

for i in range(current_graph.number_of_vertex):
	current_line = list(map(int, input().split()))
	for j in range(current_graph.number_of_vertex):
		if current_line[j] == 1:
			current_graph.vertexes[i].add_target(current_graph.vertexes[j])	

    
def color_vertexes(graph):

    colors = graph.number_of_vertex*[-1]        
    for v in range(graph.number_of_vertex):
        available_colors = [True] * graph.number_of_vertex      
        for neighbor in graph.vertexes[v].targets:
            if colors[neighbor.index] != -1:
                color = colors[neighbor.index]
                available_colors[color] = False
            for color, available in enumerate(available_colors):
                if available: colors[v] = color; break
               
    different_colors = []
    for color in colors:
        if color not in different_colors:
            different_colors.append(color)
            
    print(len(different_colors))

color_vertexes(current_graph)
